<?php
namespace pocketmine\inventory;

class StonecutterBigShapedRecipe extends ShapedRecipe{

}
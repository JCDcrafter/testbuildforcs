<?php
namespace pocketmine\inventory;

class BigShapelessRecipe extends ShapelessRecipe{

}
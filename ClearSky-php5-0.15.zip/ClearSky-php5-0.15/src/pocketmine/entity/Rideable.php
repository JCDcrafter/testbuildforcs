<?php
namespace pocketmine\entity;

interface Rideable{}
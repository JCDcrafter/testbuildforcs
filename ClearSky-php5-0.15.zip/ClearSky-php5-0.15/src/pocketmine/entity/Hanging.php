<?php
namespace pocketmine\entity;

abstract class Hanging extends Snake implements Attachable{}
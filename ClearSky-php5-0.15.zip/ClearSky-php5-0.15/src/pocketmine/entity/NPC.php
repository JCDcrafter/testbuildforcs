<?php
namespace pocketmine\entity;

interface NPC{}
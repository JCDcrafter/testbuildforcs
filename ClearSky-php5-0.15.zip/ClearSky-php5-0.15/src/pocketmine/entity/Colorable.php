<?php
namespace pocketmine\entity;

interface Colorable{}
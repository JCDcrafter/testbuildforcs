<?php
namespace pocketmine\entity;

abstract class Creature extends Living{}
<?php
namespace pocketmine\entity;

abstract class Monster extends Creature{}
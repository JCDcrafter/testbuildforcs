<?php
namespace pocketmine\entity;

interface ProjectileSource{}
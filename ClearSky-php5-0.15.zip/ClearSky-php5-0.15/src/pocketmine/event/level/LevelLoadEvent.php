<?php
namespace pocketmine\event\level;

/**
 * Called when a Level is saved
 */
class LevelLoadEvent extends LevelEvent{
	public static $handlerList = null;
}
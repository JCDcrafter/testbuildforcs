<?php
namespace pocketmine\block;


class FenceGateSpruce extends FenceGate{

	protected $id = self::FENCE_GATE_SPRUCE;

	public function getName(){
		return "Spruce Fence Gate";
	}
}
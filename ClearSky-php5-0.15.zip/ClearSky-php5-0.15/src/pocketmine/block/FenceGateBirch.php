<?php
namespace pocketmine\block;


class FenceGateBirch extends FenceGate{

	protected $id = self::FENCE_GATE_BIRCH;

	public function getName(){
		return "Birch Fence Gate";
	}
}
<?php
namespace pocketmine\block;

interface RedstoneConsumer{
	public function isRedstoneConsumer();
}